﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Erp_Proje
{
    public partial class Stokfrm : Form
    {
        public Stokfrm()
        {
            InitializeComponent();
        }

        sqlbaglantisi bgl = new sqlbaglantisi();
        private void button5_Click(object sender, EventArgs e)
        {
            Form1 fr = new Form1();
            fr.Show();
            this.Hide();
        }
        private void listele()
        {

            // Veri tablosunu data grid Viewe listeleme komutu
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("Select MALZEMEAD,MARKA,STOK from Tbl_Malzeme ", bgl.baglanti());
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void Stokfrm_Load(object sender, EventArgs e)
        {
            listele();
            try
            {
                // Bağlantıyı using içinde tanımlıyoruz
                using (SqlConnection conn = bgl.baglanti())
                {
                    SqlCommand komuts = new SqlCommand("SELECT TALEP FROM Tbl_Talep", conn);

                    // Bağlantı açık mı kontrol et
                    if (conn.State == System.Data.ConnectionState.Closed)
                        conn.Open();

                    SqlDataReader drr = komuts.ExecuteReader();

                    Rchtalep.Clear(); // RichTextBox'u temizle
                    while (drr.Read())
                    {
                        Rchtalep.AppendText(drr["TALEP"] + Environment.NewLine);
                    }



                    drr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                // Bağlantıyı oluştur ve aç
                using (SqlConnection conn = bgl.baglanti())
                {
                    // Stok sayısı 100'den küçük olanları seçen SQL sorgusu
                    string query = @"
                SELECT MALZEMEAD, MARKA, Stok 
                FROM Tbl_Malzeme 
                WHERE Stok < 100";

                    // SQL komutunu oluştur
                    SqlCommand komut = new SqlCommand(query, conn);

                    // Veriyi okumak için SqlDataReader kullan
                    SqlDataReader dr = komut.ExecuteReader();

                    // RichTextBox'ı temizle
                    rchacil.Clear();

                    // Verileri RichTextBox'a ekle
                    while (dr.Read())
                    {
                        string malzemeAd = dr["MALZEMEAD"].ToString();
                        string marka = dr["MARKA"].ToString();
                        int stok = Convert.ToInt32(dr["Stok"]);
                        rchacil.AppendText($"Malzeme: {malzemeAd}, Marka: {marka}, Stok: {stok}\n");
                    }

                    dr.Close(); // DataReader'ı kapat
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bir hata oluştu: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //  Talep tablosuna veri ekleme komutu
            SqlCommand komut = new SqlCommand(" INSERT INTO Tbl_Olustur (TALEP) values (@p1)", bgl.baglanti());
            komut.Parameters.AddWithValue("@p1", rchtxt.Text);
            komut.ExecuteNonQuery();
            bgl.baglanti().Close();
            MessageBox.Show("Talep oluşturuldu", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            rchtxt.Clear(); // Talep richtext boxını temizle
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void Rchtalep_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
