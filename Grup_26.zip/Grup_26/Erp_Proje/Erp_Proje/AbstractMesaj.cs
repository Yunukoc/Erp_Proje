﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Erp_Proje
{
     abstract class AbstractMesaj // Soyutlama için Abstract bir sınıf açıyoruz 
    {
        abstract public void mesaj();
    }
}
