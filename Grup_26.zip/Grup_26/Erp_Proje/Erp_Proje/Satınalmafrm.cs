﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Erp_Proje
{
    public partial class Satınalmafrm : Form
    {
        public Satınalmafrm()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Marka ve stok değerlerini al
                string secilenMarka = cmbmarka.SelectedItem?.ToString();
                if (string.IsNullOrEmpty(secilenMarka))
                {
                    MessageBox.Show("Lütfen bir marka seçiniz.");
                    return;
                }

                int eklenecekStok;
                if (!int.TryParse(Txtstn.Text, out eklenecekStok))
                {
                    MessageBox.Show("Lütfen geçerli bir stok miktarı giriniz.");
                    return;
                }

                // Bağlantıyı oluştur ve aç
                using (SqlConnection conn = bgl.baglanti())
                {
                    // Stok bilgisini güncelleyen SQL sorgusu
                    string query = @"
                UPDATE Tbl_Malzeme
                SET Stok = Stok + @eklenenStok
                WHERE MARKA = @marka";

                    // SQL komutunu oluştur ve parametreleri ekle
                    SqlCommand komut = new SqlCommand(query, conn);
                    komut.Parameters.AddWithValue("@eklenenStok", eklenecekStok);
                    komut.Parameters.AddWithValue("@marka", secilenMarka);

                    // Komutu çalıştır
                    int etkilenenSatir = komut.ExecuteNonQuery();
                    if (etkilenenSatir > 0)
                    {
                        MessageBox.Show("Stok başarıyla güncellendi!");
                    }
                    else
                    {
                        MessageBox.Show("Seçilen marka için stok güncellenemedi.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bir hata oluştu: " + ex.Message);
            }
            listele();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cmbmarka_SelectedIndexChanged(object sender, EventArgs e)
        {
           

           
            







        }
        sqlbaglantisi bgl = new sqlbaglantisi();  // Sql  

        private bool comboBoxUpdating = false;
        private void cmbmalzeme_SelectedIndexChanged(object sender, EventArgs e)
        {
             if (cmbmalzeme.SelectedItem == null)
                    return; // Seçim yapılmadıysa çık

                string selectedMalzemeAd = cmbmalzeme.SelectedItem.ToString();

                try
                {
                    // Marka ComboBox'ını temizle
                    cmbmarka.Items.Clear();

                    // SQL komutunu oluştur
                    SqlCommand komut = new SqlCommand("SELECT MARKA FROM Tbl_Malzeme WHERE MALZEMEAD = @malzemeAd", bgl.baglanti());
                    komut.Parameters.AddWithValue("@malzemeAd", selectedMalzemeAd);

                    // Bağlantıyı aç
                    if (bgl.baglanti().State == System.Data.ConnectionState.Closed)
                        bgl.baglanti().Open();

                    SqlDataReader dr = komut.ExecuteReader(); // Veriyi oku

                    // ComboBox'a markaları ekle
                    while (dr.Read())
                    {
                        cmbmarka.Items.Add(dr["MARKA"].ToString()); // Marka'yı ComboBox'a ekle
                    }

                    dr.Close();
                    bgl.baglanti().Close(); // Bağlantıyı kapat
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Bir hata oluştu: " + ex.Message);
                }



            


            }
        private void listele()
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("Select MALZEMEAD,MARKA,STOK from Tbl_Malzeme ", bgl.baglanti());
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

       
        private void listelestok()
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("Select *  from Tbl_Olustur ", bgl.baglanti());
            da.Fill(dt);
            dataGridView2.DataSource = dt;
        }
        private void Satınalmafrm_Load(object sender, EventArgs e)
        {

            listelestok();

            try
            {
                // Bağlantıyı using içinde tanımlıyoruz
                using (SqlConnection conn = bgl.baglanti())
                {
                    SqlCommand komuts = new SqlCommand("SELECT TALEP FROM Tbl_Olustur", conn);

                    // Bağlantı açık mı kontrol et
                    if (conn.State == System.Data.ConnectionState.Closed)
                        conn.Open();

                    SqlDataReader drr = komuts.ExecuteReader();

                    Rchtalep.Clear(); // RichTextBox'u temizle
                    while (drr.Read())
                    {
                       Rchtalep.AppendText(drr["TALEP"] + Environment.NewLine);
                    }

                    drr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }


            cmbmalzeme.Items.Clear(); // ComboBox'ı temizle

            // SQL komutunu oluştur
            SqlCommand komut = new SqlCommand("SELECT DISTINCT MALZEMEAD FROM Tbl_Malzeme", bgl.baglanti());
            SqlDataReader dr = komut.ExecuteReader(); // Veriyi oku

            // ComboBox'a verileri ekle
            while (dr.Read())
            {
                cmbmalzeme.Items.Add(dr["MALZEMEAD"].ToString()); // MalzemeAd'ı ComboBox'a ekle
            }

            dr.Close();
            bgl.baglanti().Close(); // Bağlantıyı kapat





            listele();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            

            
            

        }

        private void button4_Click(object sender, EventArgs e)
        {
            
              

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        /* SqlCommand komut2 = new SqlCommand("update Tbl_Fırma set AD=@p1, TELEFON1=@p2,TELEFON2=@p3, MAIL=@p4, FAX=@p5, IL=@p6, ILCE= @p7, VERGIDAIRE=@p8, ADRES=@p9, YETKILI=@p10 where  ID=@P11", bgl.baglanti());
            komut2.Parameters.AddWithValue("@p1", txtad.Text);*/
        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand("UPDATE Tbl_Olustur SET DURUM=@p1, TALEP=@p3 WHERE ID=@p2", bgl.baglanti());
            komut.Parameters.AddWithValue("@p1", txttalep.Text);
            komut.Parameters.AddWithValue("@p2", txtıd.Text);
            komut.Parameters.AddWithValue("@p3", txtdurum.Text);
            komut.ExecuteNonQuery();
            bgl.baglanti().Close();
            listelestok();


        }

        private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilen = dataGridView2.SelectedCells[0].RowIndex;

            // ID sütununu txtıd'ye atıyoruz.
            txtıd.Text = dataGridView2.Rows[secilen].Cells[0].Value.ToString();

            // Diğer alanları dolduruyoruz.

            txtdurum.Text = dataGridView2.Rows[secilen].Cells[1].Value.ToString();
            txttalep.Text = dataGridView2.Rows[secilen].Cells[2].Value.ToString();




        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Form1 fr = new Form1();
            fr.Show();
            this.Hide();

        }
    }
}
