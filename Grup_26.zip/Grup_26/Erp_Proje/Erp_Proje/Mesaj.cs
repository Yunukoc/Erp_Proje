﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Erp_Proje
{
    class Mesaj : AbstractMesaj
    {
        public override void mesaj()
        {
            MessageBox.Show("Kayıt işlemi başarıyla gerçekleştirildi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }
    }
}

