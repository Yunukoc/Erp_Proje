﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Erp_Proje
{
    public partial class Girisfrm : Form
    {
        public Girisfrm()
        {
            InitializeComponent();
        }
        sqlbaglantisi bgl = new sqlbaglantisi();
        private void button1_Click(object sender, EventArgs e)
        {
           
            // Şifre ve kullanıcıyı doğrulama komutları
            SqlCommand komut = new SqlCommand(" Select * FROM Tbl_Personel where TC=@p1 and SİFRE=@p2 ", bgl.baglanti());
            komut.Parameters.AddWithValue("@p1", mstc.Text);
            komut.Parameters.AddWithValue("@p2", txtsifre.Text);
            SqlDataReader sr = komut.ExecuteReader();
            if (sr.Read()) // okuma gerçekleştiriliyorsa 
            {
                pictureBox1.Enabled = true; // Butonları aktiflet
                pictureBox2.Enabled = true;
                pictureBox3.Enabled = true;
                pictureBox4.Enabled = true;
                pictureBox5.Enabled = true;

                MessageBox.Show("Giriş yapıldı", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Doğrulama işlemi doğruysa Form1 penceresine ata.
                Form1 fr = new Form1();
                fr.Show();
                this.Hide();





            }
            else
            {
                MessageBox.Show("Hatalı Giriş yaptınız.");
            }


        }

        private void Girisfrm_Load(object sender, EventArgs e)
        {
            pictureBox1.Enabled = false; // Butonun aktifliğini kapatıyoruz.
            pictureBox2.Enabled = false; // Butonun aktifliğini kapatıyoruz.
            pictureBox3.Enabled = false; // Butonun aktifliğini kapatıyoruz.
            pictureBox4.Enabled = false; // Butonun aktifliğini kapatıyoruz.
            pictureBox5.Enabled = false; // Butonun aktifliğini kapatıyoruz.
            pictureBox6.Enabled = true;  // Butonu aktif hale getiriyoruz.


        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Frmkayıt fr = new Frmkayıt();
            fr.Show();
            this.Hide();
        }
    }
}
