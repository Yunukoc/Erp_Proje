﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Erp_Proje
{
    public partial class Frmkayıt : Form
    {
        public Frmkayıt()
        {
            InitializeComponent();
        }
        sqlbaglantisi bgl = new sqlbaglantisi();
        private void button1_Click(object sender, EventArgs e)
        {
            Kullanıcı yk = new Kullanıcı(); // Kapsüllemeden veri çekme
            yk.Tc = mstc.Text; // Kapsülleme classından veri çekme
            yk.Sifre = txtsifre.Text; // Kapsülleme classından veri çekme

            
            // Personel Tablosuna veri ekleme komutu
            SqlCommand komut = new SqlCommand(" insert into Tbl_Personel(TC, SİFRE) values (@p1,@p2)", bgl.baglanti());
            komut.Parameters.AddWithValue("@p1", yk.Tc);
            komut.Parameters.AddWithValue("@p2", yk.Sifre);
            komut.ExecuteNonQuery();
            bgl.baglanti().Close();
            Mesaj ms = new Mesaj();
            ms.mesaj();
            mstc.Clear();
            txtsifre.Clear();

        }

        private void button2_Click(object sender, EventArgs e)
        { // Giris formunu gösterme ekranı
            Girisfrm fr = new Girisfrm();
            fr.Show();
            this.Hide();
        }

        private void Frmkayıt_Load(object sender, EventArgs e)
        {

        }
    }
}
