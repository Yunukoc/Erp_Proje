﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Erp_Proje
{
    public partial class Firmalarfrm : Form
    {
        public Firmalarfrm()
        {
            InitializeComponent();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtıd_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        
        private void txtad_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        sqlbaglantisi bgl = new sqlbaglantisi();

        void listele()
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("Select * from Tbl_Fırma ", bgl.baglanti());
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        
        private void btnkaydet_Click(object sender, EventArgs e)
        {
            listele();
        }

        private void btnekle_Click(object sender, EventArgs e)
        {
            // verileri kaydetme
            SqlCommand komut1 = new SqlCommand("insert into Tbl_Fırma (AD,TELEFON1,TELEFON2,MAIL,FAX,IL,ILCE,VERGIDAIRE,ADRES,YETKILI) values (@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10) ", bgl.baglanti());
            komut1.Parameters.AddWithValue("@p1", txtad.Text);
            komut1.Parameters.AddWithValue("@p2", msktel1.Text);
            komut1.Parameters.AddWithValue("@p3", msktel2.Text);
            komut1.Parameters.AddWithValue("@p4", txtmaıl.Text);
            komut1.Parameters.AddWithValue("@p5", txtfax.Text);
            komut1.Parameters.AddWithValue("@p6", textıl.Text);
            komut1.Parameters.AddWithValue("@p7", textılce.Text);
            komut1.Parameters.AddWithValue("@p8", textvergı.Text);
            komut1.Parameters.AddWithValue("@p9", richadres.Text);
            komut1.Parameters.AddWithValue("@p10", txtyetkılı.Text);


            komut1.ExecuteNonQuery();
            bgl.baglanti().Close();
            Mesaj ms = new Mesaj(); // Abstract Soyutlamayı burada kullanıyoruz.
            ms.mesaj();
            listele();

        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            SqlCommand Kayıtsil = new SqlCommand("Delete From  Tbl_FIRMA where ID= @p1 ", bgl.baglanti());
            Kayıtsil.Parameters.AddWithValue("@p1", txtıd.Text);
            Kayıtsil.ExecuteNonQuery();
            bgl.baglanti().Close();
            MessageBox.Show(" Silme işlemi gerçekleştirildi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            listele();
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        { 

            // Bu kod bloğundaki Amacımız fareye ile çift tıkladığımızda veri tabanındaki tablosundaki değerleri form kutularına yansıtıyor
            int secilen = dataGridView1.SelectedCells[0].RowIndex;

            // ID sütununu txtıd'ye atıyoruz.
            txtıd.Text = dataGridView1.Rows[secilen].Cells[0].Value.ToString();

            // Diğer alanları dolduruyoruz.
            txtad.Text = dataGridView1.Rows[secilen].Cells[1].Value.ToString();
            txtyetkılı.Text = dataGridView1.Rows[secilen].Cells[2].Value.ToString();
            msktel1.Text = dataGridView1.Rows[secilen].Cells[3].Value.ToString();
            msktel2.Text = dataGridView1.Rows[secilen].Cells[4].Value.ToString();
            txtmaıl.Text = dataGridView1.Rows[secilen].Cells[5].Value.ToString();
            txtfax.Text = dataGridView1.Rows[secilen].Cells[6].Value.ToString();

            textıl.Text = dataGridView1.Rows[secilen].Cells[7].Value.ToString();
            textılce.Text = dataGridView1.Rows[secilen].Cells[8].Value.ToString();
            textvergı.Text = dataGridView1.Rows[secilen].Cells[9].Value.ToString();
            richadres.Text = dataGridView1.Rows[secilen].Cells[10].Value.ToString();







        }

        private void btngüncelle_Click(object sender, EventArgs e)
        { 
            // Güncelleme işlemini yapmak için Oluşturulan komut
            // Sql güncelleme komutu 
            SqlCommand komut2 = new SqlCommand("update Tbl_Fırma set AD=@p1, TELEFON1=@p2,TELEFON2=@p3, MAIL=@p4, FAX=@p5, IL=@p6, ILCE= @p7, VERGIDAIRE=@p8, ADRES=@p9, YETKILI=@p10 where  ID=@P11", bgl.baglanti());
            komut2.Parameters.AddWithValue("@p1", txtad.Text); // Parametreleri form kutuları  ile eşleştiriyoruz.
            komut2.Parameters.AddWithValue("@p2", msktel1.Text);
            komut2.Parameters.AddWithValue("@p3", msktel2.Text);
            komut2.Parameters.AddWithValue("@p4", txtmaıl.Text);
            komut2.Parameters.AddWithValue("@p5", txtfax.Text);
            komut2.Parameters.AddWithValue("@p6", textıl.Text);
            komut2.Parameters.AddWithValue("@p7", textılce.Text);
            komut2.Parameters.AddWithValue("@p8", textvergı.Text);
            komut2.Parameters.AddWithValue("@p9", richadres.Text);
            komut2.Parameters.AddWithValue("@p10", txtyetkılı.Text);
            komut2.Parameters.AddWithValue("@p11", txtıd.Text);
            komut2.ExecuteNonQuery(); // Komutları okuma
            bgl.baglanti().Close();// Bağlantıyı kapatma
            Guncellemesaj ms = new Guncellemesaj(); // Poliformizm Burada Kullanılıyor.
            ms.mesaj();
            listele();


        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Form 1 sayfanı açmak için yazılan Komut
            Form1 fr = new Form1();
            fr.Show();
            this.Hide();
            

        }

        private void Firmalarfrm_Load(object sender, EventArgs e)
        {

        }
    }
}
