﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Erp_Proje
{
    class sqlbaglantisi
    {
        public SqlConnection baglanti()
        {
            SqlConnection baglan = new SqlConnection(@"Data Source=LAPTOP-1KLI1KSA;Initial Catalog=DboTicariOtomasyon;Integrated Security=True");

            if (baglan.State == System.Data.ConnectionState.Closed) // Bağlantı kapalıysa aç
            {
                baglan.Open();
            }
            return baglan;
        }

    }
}
