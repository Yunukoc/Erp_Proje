﻿
namespace Erp_Proje
{
    partial class Stokfrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Rchtalep = new System.Windows.Forms.RichTextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnkaydet = new System.Windows.Forms.Button();
            this.rchtxt = new System.Windows.Forms.RichTextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.btnacil = new System.Windows.Forms.Button();
            this.rchacil = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Location = new System.Drawing.Point(2, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(623, 583);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Stok Takip Ekranı";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Rchtalep);
            this.groupBox4.Location = new System.Drawing.Point(0, 335);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(617, 230);
            this.groupBox4.TabIndex = 12;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Talep Ekranı";
            // 
            // Rchtalep
            // 
            this.Rchtalep.Location = new System.Drawing.Point(6, 21);
            this.Rchtalep.Name = "Rchtalep";
            this.Rchtalep.Size = new System.Drawing.Size(605, 203);
            this.Rchtalep.TabIndex = 0;
            this.Rchtalep.Text = "";
            this.Rchtalep.TextChanged += new System.EventHandler(this.Rchtalep_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 21);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(612, 313);
            this.dataGridView1.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnkaydet);
            this.groupBox2.Controls.Add(this.rchtxt);
            this.groupBox2.Location = new System.Drawing.Point(620, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(486, 223);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Talep Oluştur";
            // 
            // btnkaydet
            // 
            this.btnkaydet.Location = new System.Drawing.Point(146, 142);
            this.btnkaydet.Name = "btnkaydet";
            this.btnkaydet.Size = new System.Drawing.Size(192, 51);
            this.btnkaydet.TabIndex = 1;
            this.btnkaydet.Text = "Oluştur";
            this.btnkaydet.UseVisualStyleBackColor = true;
            this.btnkaydet.Click += new System.EventHandler(this.button1_Click);
            // 
            // rchtxt
            // 
            this.rchtxt.Location = new System.Drawing.Point(6, 21);
            this.rchtxt.Name = "rchtxt";
            this.rchtxt.Size = new System.Drawing.Size(480, 112);
            this.rchtxt.TabIndex = 0;
            this.rchtxt.Text = "";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.btnacil);
            this.groupBox3.Controls.Add(this.rchacil);
            this.groupBox3.Location = new System.Drawing.Point(620, 227);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(486, 356);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Acil İhtiyaçları Görüntüle";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(404, 316);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(82, 34);
            this.button5.TabIndex = 3;
            this.button5.Text = "Geri Git";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnacil
            // 
            this.btnacil.Location = new System.Drawing.Point(42, 275);
            this.btnacil.Name = "btnacil";
            this.btnacil.Size = new System.Drawing.Size(228, 54);
            this.btnacil.TabIndex = 3;
            this.btnacil.Text = "Acil Stok İhtiyaçlarını Görüntüle";
            this.btnacil.UseVisualStyleBackColor = true;
            this.btnacil.Click += new System.EventHandler(this.button4_Click);
            // 
            // rchacil
            // 
            this.rchacil.Location = new System.Drawing.Point(6, 53);
            this.rchacil.Name = "rchacil";
            this.rchacil.Size = new System.Drawing.Size(480, 202);
            this.rchacil.TabIndex = 0;
            this.rchacil.Text = "";
            // 
            // Stokfrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1108, 595);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Stokfrm";
            this.Text = "Stokfrm";
            this.Load += new System.EventHandler(this.Stokfrm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnkaydet;
        private System.Windows.Forms.RichTextBox rchtxt;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnacil;
        private System.Windows.Forms.RichTextBox rchacil;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RichTextBox Rchtalep;
    }
}