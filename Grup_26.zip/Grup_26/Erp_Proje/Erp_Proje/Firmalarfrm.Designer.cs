﻿
namespace Erp_Proje
{
    partial class Firmalarfrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.textvergı = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textılce = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textıl = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnekle = new System.Windows.Forms.Button();
            this.btngüncelle = new System.Windows.Forms.Button();
            this.txtfax = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtmaıl = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.msktel2 = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.msktel1 = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnsil = new System.Windows.Forms.Button();
            this.txtyetkılı = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnlistele = new System.Windows.Forms.Button();
            this.richadres = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtad = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtıd = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.textvergı);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.textılce);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.textıl);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.btnekle);
            this.groupBox1.Controls.Add(this.btngüncelle);
            this.groupBox1.Controls.Add(this.txtfax);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtmaıl);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.msktel2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.msktel1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnsil);
            this.groupBox1.Controls.Add(this.txtyetkılı);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btnlistele);
            this.groupBox1.Controls.Add(this.richadres);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtad);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtıd);
            this.groupBox1.Location = new System.Drawing.Point(785, -5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(322, 598);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(37, 396);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(82, 34);
            this.button5.TabIndex = 37;
            this.button5.Text = "Geri Git";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textvergı
            // 
            this.textvergı.Location = new System.Drawing.Point(132, 336);
            this.textvergı.Name = "textvergı";
            this.textvergı.Size = new System.Drawing.Size(179, 22);
            this.textvergı.TabIndex = 36;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 336);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 17);
            this.label11.TabIndex = 35;
            this.label11.Text = "VERGIDAIRESI";
            // 
            // textılce
            // 
            this.textılce.Location = new System.Drawing.Point(131, 301);
            this.textılce.Name = "textılce";
            this.textılce.Size = new System.Drawing.Size(179, 22);
            this.textılce.TabIndex = 34;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(88, 301);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 17);
            this.label10.TabIndex = 33;
            this.label10.Text = "ILCE";
            // 
            // textıl
            // 
            this.textıl.Location = new System.Drawing.Point(132, 266);
            this.textıl.Name = "textıl";
            this.textıl.Size = new System.Drawing.Size(179, 22);
            this.textıl.TabIndex = 32;
            this.textıl.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(106, 266);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(19, 17);
            this.label9.TabIndex = 31;
            this.label9.Text = "IL";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // btnekle
            // 
            this.btnekle.Location = new System.Drawing.Point(202, 525);
            this.btnekle.Name = "btnekle";
            this.btnekle.Size = new System.Drawing.Size(114, 37);
            this.btnekle.TabIndex = 30;
            this.btnekle.Text = "Ekle";
            this.btnekle.UseVisualStyleBackColor = true;
            this.btnekle.Click += new System.EventHandler(this.btnekle_Click);
            // 
            // btngüncelle
            // 
            this.btngüncelle.Location = new System.Drawing.Point(11, 471);
            this.btngüncelle.Name = "btngüncelle";
            this.btngüncelle.Size = new System.Drawing.Size(114, 37);
            this.btngüncelle.TabIndex = 29;
            this.btngüncelle.Text = "Güncelle";
            this.btngüncelle.UseVisualStyleBackColor = true;
            this.btngüncelle.Click += new System.EventHandler(this.btngüncelle_Click);
            // 
            // txtfax
            // 
            this.txtfax.Location = new System.Drawing.Point(132, 231);
            this.txtfax.Name = "txtfax";
            this.txtfax.Size = new System.Drawing.Size(179, 22);
            this.txtfax.TabIndex = 28;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(95, 231);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 17);
            this.label7.TabIndex = 27;
            this.label7.Text = "FAX";
            // 
            // txtmaıl
            // 
            this.txtmaıl.Location = new System.Drawing.Point(132, 196);
            this.txtmaıl.Name = "txtmaıl";
            this.txtmaıl.Size = new System.Drawing.Size(179, 22);
            this.txtmaıl.TabIndex = 26;
            this.txtmaıl.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(86, 196);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 17);
            this.label6.TabIndex = 25;
            this.label6.Text = "MAIL";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // msktel2
            // 
            this.msktel2.Location = new System.Drawing.Point(132, 161);
            this.msktel2.Mask = "(999) 000-0000";
            this.msktel2.Name = "msktel2";
            this.msktel2.Size = new System.Drawing.Size(179, 22);
            this.msktel2.TabIndex = 24;
            this.msktel2.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox2_MaskInputRejected);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(80, 161);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 17);
            this.label5.TabIndex = 23;
            this.label5.Text = "TEL2:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // msktel1
            // 
            this.msktel1.Location = new System.Drawing.Point(132, 126);
            this.msktel1.Mask = "(999) 000-0000";
            this.msktel1.Name = "msktel1";
            this.msktel1.Size = new System.Drawing.Size(179, 22);
            this.msktel1.TabIndex = 22;
            this.msktel1.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox1_MaskInputRejected);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(80, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 17);
            this.label4.TabIndex = 21;
            this.label4.Text = "TEL1:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // btnsil
            // 
            this.btnsil.Location = new System.Drawing.Point(11, 525);
            this.btnsil.Name = "btnsil";
            this.btnsil.Size = new System.Drawing.Size(114, 37);
            this.btnsil.TabIndex = 20;
            this.btnsil.Text = "Sil";
            this.btnsil.UseVisualStyleBackColor = true;
            this.btnsil.Click += new System.EventHandler(this.btnsil_Click);
            // 
            // txtyetkılı
            // 
            this.txtyetkılı.Location = new System.Drawing.Point(132, 91);
            this.txtyetkılı.Name = "txtyetkılı";
            this.txtyetkılı.Size = new System.Drawing.Size(179, 22);
            this.txtyetkılı.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(63, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 17);
            this.label3.TabIndex = 18;
            this.label3.Text = "YETKİLİ:";
            // 
            // btnlistele
            // 
            this.btnlistele.Location = new System.Drawing.Point(202, 471);
            this.btnlistele.Name = "btnlistele";
            this.btnlistele.Size = new System.Drawing.Size(114, 37);
            this.btnlistele.TabIndex = 16;
            this.btnlistele.Text = "Listele";
            this.btnlistele.UseVisualStyleBackColor = true;
            this.btnlistele.Click += new System.EventHandler(this.btnkaydet_Click);
            // 
            // richadres
            // 
            this.richadres.Location = new System.Drawing.Point(132, 369);
            this.richadres.Name = "richadres";
            this.richadres.Size = new System.Drawing.Size(179, 61);
            this.richadres.TabIndex = 15;
            this.richadres.Text = "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(70, 367);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 17);
            this.label8.TabIndex = 14;
            this.label8.Text = "ADRES";
            // 
            // txtad
            // 
            this.txtad.Location = new System.Drawing.Point(132, 56);
            this.txtad.Name = "txtad";
            this.txtad.Size = new System.Drawing.Size(179, 22);
            this.txtad.TabIndex = 4;
            this.txtad.TextChanged += new System.EventHandler(this.txtad_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(88, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "AD:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(94, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "ID:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtıd
            // 
            this.txtıd.Location = new System.Drawing.Point(132, 21);
            this.txtıd.Name = "txtıd";
            this.txtıd.Size = new System.Drawing.Size(179, 22);
            this.txtıd.TabIndex = 0;
            this.txtıd.TextChanged += new System.EventHandler(this.txtıd_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(-1, -4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(786, 598);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentDoubleClick);
            // 
            // Firmalarfrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1108, 595);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Firmalarfrm";
            this.Text = "Firmalarfrm";
            this.Load += new System.EventHandler(this.Firmalarfrm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnsil;
        private System.Windows.Forms.TextBox txtyetkılı;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnlistele;
        private System.Windows.Forms.RichTextBox richadres;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtad;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtıd;
        private System.Windows.Forms.TextBox textılce;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textıl;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnekle;
        private System.Windows.Forms.Button btngüncelle;
        private System.Windows.Forms.TextBox txtfax;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtmaıl;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox msktel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox msktel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textvergı;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button5;
    }
}