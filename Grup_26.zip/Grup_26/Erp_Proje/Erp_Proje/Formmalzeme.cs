﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Erp_Proje
{
    public partial class Formmalzeme : Form
    {
        public Formmalzeme()
        {
            InitializeComponent();
        }
        sqlbaglantisi bgl = new sqlbaglantisi();

        void listele()
        {
            //  Veri tabanındaki tabloyu data grid view'nın içine aktarır.
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("Select * from Tbl_Malzeme ", bgl.baglanti());
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Formmalzeme_Load(object sender, EventArgs e)
        {
            listele(); 
        }

        private void btnkaydet_Click(object sender, EventArgs e)
        {
            // verileri kaydetme
            SqlCommand komut1 = new SqlCommand("insert into Tbl_Malzeme (MALZEMEAD,MARKA,STOK,DETAY) values (@p1,@p2,@p3,@p4) ", bgl.baglanti());
            komut1.Parameters.AddWithValue("@p1", txtad.Text);
            komut1.Parameters.AddWithValue("@p2", txtmarka.Text);
            komut1.Parameters.AddWithValue("@p3", int.Parse(txtstok.Text));          
            komut1.Parameters.AddWithValue("@p4", richdetay.Text);
            komut1.ExecuteNonQuery();
            bgl.baglanti().Close();
            Mesaj ms = new Mesaj(); // Abstract Soyutlamayı burada kullanıyoruz.
            ms.mesaj();
            listele();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Sql komutlarıyla silme işlemeni gerçekleştiriyoruz.
            SqlCommand Kayıtsil = new SqlCommand("Delete From  Tbl_Malzeme where ID= @p1 ", bgl.baglanti());
            Kayıtsil.Parameters.AddWithValue("@p1", txtıd.Text);
            Kayıtsil.ExecuteNonQuery();
            bgl.baglanti().Close();
            MessageBox.Show("Malzeme Silindi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            listele();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilen = dataGridView1.SelectedCells[0].RowIndex;

            // ID sütununu txtıd'ye atıyoruz.
            txtıd.Text = dataGridView1.Rows[secilen].Cells[0].Value.ToString();

            // Diğer alanları dolduruyoruz.
            txtad.Text = dataGridView1.Rows[secilen].Cells[1].Value.ToString();
            txtmarka.Text = dataGridView1.Rows[secilen].Cells[2].Value.ToString();
            txtstok.Text = dataGridView1.Rows[secilen].Cells[3].Value.ToString();
            richdetay.Text = dataGridView1.Rows[secilen].Cells[4].Value.ToString();




        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 fr = new Form1();
            fr.Show();
            this.Close();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
