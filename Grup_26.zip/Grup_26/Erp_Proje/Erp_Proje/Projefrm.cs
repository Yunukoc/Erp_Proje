﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Erp_Proje
{
    public partial class Projefrm : Form
    {
        public Projefrm()
        {
            InitializeComponent();
        }
        sqlbaglantisi bgl = new sqlbaglantisi();

        
        private void Projefrm_Load(object sender, EventArgs e)
        {
            cmbproje.Items.Clear(); // ComboBox'ı temizle

            // SQL komutunu oluştur
            SqlCommand komut = new SqlCommand("SELECT DISTINCT AD FROM Tbl_Proje", bgl.baglanti());
            SqlDataReader dr = komut.ExecuteReader(); // Veriyi oku

            // ComboBox'a verileri ekle
            while (dr.Read())
            {
                cmbproje.Items.Add(dr["AD"].ToString()); // MalzemeAd'ı ComboBox'a ekle
            }

            dr.Close();
            bgl.baglanti().Close(); // Bağlantıyı kapat
        }

        private void btnkaydet_Click(object sender, EventArgs e)
        {
            // Sql tablosuna veri gönderme
            SqlCommand komut = new SqlCommand(" INSERT INTO Tbl_TALEP (TALEP) values (@p1)", bgl.baglanti());
            komut.Parameters.AddWithValue("@p1", rchtalep2.Text);
            komut.ExecuteNonQuery();
            bgl.baglanti().Close();
            Mesaj ms = new Mesaj(); // Abstract Soyutlamayı burada kullanıyoruz.
            ms.mesaj();
            rchtalep2.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 fr = new Form1();
            fr.Show();
            this.Hide();
        }
    }
}
