﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Erp_Proje
{
    class Kullanıcı
    {
        // Private alanlar
       
        private string TC;
       
        private string SİFRE;

       

        // Tc Özelliği
        public string Tc
        {
            get { return TC; }
            set { TC = value; }
        }

       

        // Sifre Özelliği
        public string Sifre
        {
            get { return SİFRE; }
            set { SİFRE = value; }
        }
    }
}
