﻿using System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Erp_Proje
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ribbonControl1_Click(object sender, EventArgs e)
        {

        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
            fr = new Formmalzeme(); // Tanımladığımız nesneyi form ile eşleştiriyoruz.
            fr.Show(); // Fr kod adlı formu açıyoruz.
            this.Hide(); // Bu formu kapatıyoruz.
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // Form üzerindeki tüm kontrolleri tara (GroupBox dahil)
            AddMouseEventsToPictureBoxes(this.Controls);

           
            
           

        }
        Formmalzeme fr; // Nesne türetiyoruz
        private void AddMouseEventsToPictureBoxes(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is PictureBox pictureBox)
                {
                    // PictureBox olaylarını bağla
                    pictureBox.MouseEnter += PictureBox_MouseEnter;
                    pictureBox.MouseLeave += PictureBox_MouseLeave;
                }
                else if (control is GroupBox || control is Panel || control.HasChildren)
                {
                    // Eğer bir GroupBox veya başka bir kapsayıcı kontrol varsa, alt kontrolleri tara
                    AddMouseEventsToPictureBoxes(control.Controls);
                }
            }
        }

        private void PictureBox_MouseEnter(object sender, EventArgs e)
        {
            if (sender is PictureBox pictureBox)
            {
                // Fare PictureBox üzerine geldiğinde kenarlık ekle ve işaretçiyi değiştir
                pictureBox.BorderStyle = BorderStyle.FixedSingle;
                pictureBox.Cursor = Cursors.Hand;
            }
        }

        private void PictureBox_MouseLeave(object sender, EventArgs e)
        {
            if (sender is PictureBox pictureBox)
            {
                // Fare PictureBox'tan ayrıldığında kenarlığı kaldır ve işaretçiyi sıfırla
                pictureBox.BorderStyle = BorderStyle.None;
                pictureBox.Cursor = Cursors.Default;
            }





        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Satınalmafrm sf = new Satınalmafrm();
            sf.Show();
            this.Hide();


        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        Firmalarfrm er = new Firmalarfrm();
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            er.Show();
            this.Hide();
        }
       

       

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Stokfrm fr = new Stokfrm();
            fr.Show();
            this.Hide();
         
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Projefrm fr = new Projefrm();
            fr.Show();
            this.Hide();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Frmkayıt fr = new Frmkayıt();
            fr.Show();
            this.Hide();
        }
        sqlbaglantisi bgl = new sqlbaglantisi();
        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}