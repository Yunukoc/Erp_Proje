﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Erp_Proje
{
    class Guncellemesaj : AbstractMesaj // Polimorfizm işlemini burada gaerçekleştiriyoruz
    {
        public override void mesaj()
        {
            MessageBox.Show("Güncelleme İşlemi Gerçekleştirildi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }
    }
}
